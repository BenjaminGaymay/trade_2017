In this directory :
- crypto: ETHEREUM in EUROS
- raw_material: GOLD in DOLLAR
- stock_exchange: DOW_JONES in DOLLAR
- forex: 1 EURO in YENS